import React, { useState, useEffect } from "react";
import axios from "axios";

const Headline = () => {
  const [news, setUser] = useState([]);

  useEffect(() => {
    loadNews();
  }, []);

  const loadNews = async () => {
    const result = await axios.get("http://localhost:3003/news");
    setUser(result.data);
  };


  return (
    <div className="component newsletter-header-container">    
    
        <div className="header-and-description-container ">
          <div className="headline">
            <div>
             <table class="table border shadow">
    <h4 className="breadcrumb-title">LATEST STORY</h4>  
          <tbody class="thead-dark">
            {news.map((story, index) => (
              <td>
                <center><h4>#{index + 1}</h4>
                <a href={story.link}>{story.title}</a></center>
              </td>
            ))}
          </tbody>
        </table>
    </div>
    <div class="header-description-container">
      <div class="header-description">
      </div>
    </div>
    </div>
    </div>
            
    <br/><br/><br/><br/><br/><br/><br/>
    </div>




  );
};

export default Headline;
