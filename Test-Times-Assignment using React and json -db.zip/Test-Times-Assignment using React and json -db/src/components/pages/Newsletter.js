import React, { useState, useEffect } from "react";
import axios from "axios";

const Newsletter = () => {
  const [users, setUser] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:3003/users");
    setUser(result.data);
  };


  return (
    <div className="container">
      <div className="py-6">
   
        <table class="table border ">
        <center> LATEST STORY </center>
          <tbody>
            {users.map((user, index) => (
              <td class="ft size">
                <center><h1>#{index + 1}</h1>
                <a href={user.link}>{user.title}</a></center>
        
              </td>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Newsletter;
