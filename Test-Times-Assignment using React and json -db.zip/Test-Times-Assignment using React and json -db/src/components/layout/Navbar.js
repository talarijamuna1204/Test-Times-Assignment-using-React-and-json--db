import React from "react";
import { Link, NavLink } from "react-router-dom";
const Navbar = () => {
  return (
    <div class="template-multi-newsletter-signup">
    <header class="navigation">
        
      <nav class="main hide-on-scroll can-animate">
        <div class="container primary">
          <div class="container-inner  left">
            <button class="menu-btn">
              <div class="menu-btn-box">
                <div class="menu-btn-inner"></div>
              </div>
            </button>
            
            <div class="logo">
            <Link className="navbar-brand" data-action="primary-nav-logo" aria-label="Logo" exact to="/">
            <img src="logo.png" alt="timesofindia" width="90px" height="50%"/>              
              </Link>
              <div class="featured-links desktop-only">
          <ul>
            <li>
              <NavLink className="nav-link" exact to="/american-must-change">
                AMERICAN MUST CHANGE
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/racism-and-covid-19">
                RACISM AND COVID 19
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/inequality">
                INEQUALITY
              </NavLink>
              
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/black-disabled-and-at-risk">
                BLACK, DISABLED AND AT RISK 
              </NavLink>              
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/newsletter">
              NEWSLETTER
              </NavLink>              
            </li>


          </ul>
       </div>

            
              </div>
            </div>


            <div class="buttons ">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" role="img" aria-hidden="true" tabindex="-1">
        <path fill="#685F55" d="M14.1 14.751a5.53 5.53 0 1 1 .651-.651L19 18.348l-.652.652-4.248-4.249zm-3.557.4a4.608 4.608 0 1 0 0-9.216 4.608 4.608 0 0 0 0 9.215z">

        </path>
      </svg>
      </div>
            </div>
            </nav>
            
            <div class="nav-placeholder">
      </div>
            </header>
            

            </div>

           

  );
};

export default Navbar;
